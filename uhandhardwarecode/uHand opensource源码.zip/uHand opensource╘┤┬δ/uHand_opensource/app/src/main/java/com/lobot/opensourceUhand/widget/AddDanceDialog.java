package com.lobot.opensourceUhand.widget;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.lobot.opensourceUhand.model.CommandModel;
import com.lobot.opensourceUhand.db.CommandDAO;
import com.lobot.opensourceUhand.R;

/**
 * 添加舞蹈对话框
 * Created by hejie on 2015/8/26.
 */
public class AddDanceDialog extends BaseDialog implements DialogInterface.OnClickListener {

    private EditText titleET;
    private EditText actionET;

    private int danceId;
    private String danceTitle;
    private String titleHint;
    private String actionHint;
    private String danceAction;

    private int type;
    private boolean addMode;

    static private int DBtype;

    public static DialogFragment create(Context context, FragmentManager fm, int type,int dbtype) {
        return create(context, fm, type, 0, null, null,dbtype);
    }

    public static DialogFragment create(Context context, FragmentManager fm, int type,
                                        int danceId, String danceTitle, String danceAction,int dbtype) {
        AddDanceDialog dialog = new AddDanceDialog();
        dialog.context = context;
        dialog.type = type;
        if (type == CommandModel.TYPE_DANCE) {
            dialog.title = context.getString(R.string.dialog_dance_add_title);
        } else if (type == CommandModel.TYPE_ACTION) {
            dialog.title = context.getString(R.string.dialog_action_add_title);
            dialog.titleHint = context.getString(R.string.dialog_action_add_hint_title);
            dialog.actionHint = context.getString(R.string.dialog_action_add_hint_action);
        }
        DBtype = dbtype;
        dialog.leftBtnText = context.getString(R.string.dialog_cancel);
        dialog.rightBtnText = context.getString(R.string.dialog_yes);
        dialog.danceId = danceId;
        dialog.danceTitle = danceTitle;
        dialog.danceAction = danceAction;
        dialog.addMode = TextUtils.isEmpty(danceTitle) && TextUtils.isEmpty(danceAction);
        dialog.show(fm, "AddDanceDialog");
        return dialog;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setOnClickListener(this);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.layout_dance_add, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        titleET = (EditText) view.findViewById(R.id.dance_add_title);
        actionET = (EditText) view.findViewById(R.id.dance_add_action);
        if (!TextUtils.isEmpty(danceTitle))
            titleET.setText(danceTitle);
        if (!TextUtils.isEmpty(titleHint))
            titleET.setHint(titleHint);
        if (!TextUtils.isEmpty(danceAction))
            actionET.setText(danceAction);
        if (!TextUtils.isEmpty(actionHint))
            actionET.setHint(actionHint);
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        switch (which) {
            case BUTTON_POSITIVE:
                if (TextUtils.isEmpty(titleET.getText())) {
                    if (type == CommandModel.TYPE_DANCE)
                        Toast.makeText(context, R.string.dialog_dance_add_title_requite, Toast.LENGTH_SHORT).show();
                    else if (type == CommandModel.TYPE_ACTION)
                        Toast.makeText(context, R.string.dialog_action_add_title_requite, Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(actionET.getText())) {
                    if (type == CommandModel.TYPE_DANCE)
                        Toast.makeText(context, R.string.dialog_dance_add_action_requite, Toast.LENGTH_SHORT).show();
                    else if (type == CommandModel.TYPE_ACTION)
                        Toast.makeText(context, R.string.dialog_action_add_action_requite, Toast.LENGTH_SHORT).show();
                    return;
                }
                CommandModel dance = new CommandModel(titleET.getText().toString(), Integer.valueOf(actionET.getText().toString()), true, type);
                CommandDAO dao = new CommandDAO(context,DBtype);
                if (addMode) {
                    if (dao.insert(dance)) {
                        Toast.makeText(context, R.string.dialog_dance_add_success, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, R.string.dialog_dance_add_failure, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    dance.setId(danceId);
                    if (dao.update(dance)) {
                        Toast.makeText(context, R.string.dialog_dance_update_success, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, R.string.dialog_dance_add_failure, Toast.LENGTH_SHORT).show();
                    }
                }
                break;
            case BUTTON_NEGATIVE:

                break;
        }
    }
}
