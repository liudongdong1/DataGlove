package com.lobot.opensourceUhand;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.lobot.opensourceUhand.R;

public class HelpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
    }

    public void onClick(View v)
    {
        finish();
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
