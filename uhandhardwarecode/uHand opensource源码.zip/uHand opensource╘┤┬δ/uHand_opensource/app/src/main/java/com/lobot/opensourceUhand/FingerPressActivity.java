package com.lobot.opensourceUhand;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.text.Html;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.lobot.opensourceUhand.R;
import com.lobot.opensourceUhand.commen.Constants;
import com.lobot.opensourceUhand.connect.BLEManager;
import com.lobot.opensourceUhand.model.ByteCommand;
import com.lobot.opensourceUhand.model.CommandModel;
import com.lobot.opensourceUhand.uitls.LogUtil;
import com.lobot.opensourceUhand.widget.DanceDialog;
import com.lobot.opensourceUhand.widget.PromptDialog;
import com.lobot.opensourceUhand.widget.SearchDialog;
import com.lobot.opensourceUhand.widget.SetDefaultAngle;
import com.lobot.opensourceUhand.widget.SetDefaultPressAngle;
import com.lobot.opensourceUhand.widget.SetDialog;
import com.lobot.opensourceUhand.widget.SetServoSpeed;

import java.io.File;
import java.io.FileOutputStream;

public class FingerPressActivity extends Activity implements View.OnTouchListener,SearchDialog.OnDeviceSelectedListener {

    private static final String TAG = FingerPressActivity.class.getSimpleName();

    /**
     * 蓝牙连接重试次数
     */

    private  static final int FINGER1_ANGLE_BEND = 1500;
    private  static final int FINGER2_ANGLE_BEND = 1400;
    private  static final int FINGER3_ANGLE_BEND = 1400;
    private  static final int FINGER4_ANGLE_BEND = 1400;
    private  static final int FINGER5_ANGLE_BEND = 1500;


    private boolean isConnected = false;
    private Handler mHandler;
    private ImageButton btStateBtn;
    private static final int RETRY_TIMES = 3;
    public static BluetoothAdapter mBluetoothAdapter = null;
    public static BLEManager bleManager;
    public static BluetoothDevice mBluetoothDevice;

    private ImageButton touchFingers[] = new ImageButton[5];

    private int fingerLoose[] = new int[5];

    private int fingerBend[] = new int[5];

    /**
     * 连接次数
     */
    private int connectTimes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finger_press);
        mHandler = new Handler(new MsgCallBack());
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        connectTimes = 0;
        btStateBtn = (ImageButton) findViewById(R.id.bluetooth_btn);
        touchFingers[0] = (ImageButton)findViewById(R.id.square1);
        touchFingers[1] = (ImageButton)findViewById(R.id.square2);
        touchFingers[2] = (ImageButton)findViewById(R.id.square3);
        touchFingers[3] = (ImageButton)findViewById(R.id.square4);
        touchFingers[4] = (ImageButton)findViewById(R.id.square5);
        for(int i = 0; i< touchFingers.length;i++)
        {
            touchFingers[i].setOnTouchListener(this);
        }
        setDefaultAngles();
        setDefaultPressAngles();
    }

    @Override
    public void onResume()
    {
        super.onResume();
        bleManager = BLEManager.getInstance();
        isConnected = bleManager.isConnected();
        bleManager.setHandler(mHandler);
        LogUtil.i(TAG, "onResume isConnected= " + isConnected);
        if (isConnected)
            btStateBtn.setImageResource(R.drawable.bluetooth_connected);
        else
            btStateBtn.setImageResource(R.drawable.bluetooth_disconnected);
    }

    @Override
    public void onBackPressed()
    {
        finish();
    }

    public void onClick(View v)
    {
        int id = v.getId();
        int i;
        switch (id) {
            case R.id.bluetooth_btn: // 蓝牙
                if (mBluetoothAdapter.isEnabled()) {
                    if (isConnected) {
                        PromptDialog.create(this, getFragmentManager(), getString(R.string.disconnect_tips_title),
                                getString(R.string.disconnect_tips_connect), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        if (DialogInterface.BUTTON_POSITIVE == which) {
                                            bleManager.stop();
                                        }
                                    }
                                });
                    } else {
                        SearchDialog.createDialog(getFragmentManager(), this);
                    }
                } else {
                    Toast.makeText(this, R.string.tips_open_bluetooth, Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
                }
                break;

            case R.id.stop_btn://复位舵机角度
                bleManager.removeAll();
                for (i = 0; i < PalmActivity.fingersAngle.length; i++) {
                    PalmActivity.fingersAngle[i] = 1500;
                }
                byte[] byteArray = {0x55, 0x55, 0x02, 0x07};
                ByteCommand.Builder builder = new ByteCommand.Builder();
                builder.addCommand(byteArray, 100);
                byte[] byteArrayONE = {0x55, 0x55, 0x05, 0x06, 0x00, 0x01, 0x00};
                builder.addCommand(byteArrayONE, 100);
                bleManager.send(builder.createCommands());
                if (!isConnected)
                    Toast.makeText(this, R.string.send_tips_no_connected, Toast.LENGTH_SHORT).show();
                break;

            case R.id.seftdefine_btn:
                DanceDialog.createDialog(this, getFragmentManager(), CommandModel.TYPE_ACTION, 1, new DanceDialog.OnDanceClickListener() {
                    @Override
                    public void onDanceClick(int action) {
                        byte[] byteArray = {0x55, 0x55, 0x05, 0x06, 0x00, 0x01, 0x00};
                        byteArray[4] = (byte) (action & 0xff);
                        ByteCommand.Builder builder = new ByteCommand.Builder();
                        builder.addCommand(byteArray, 100);
                        bleManager.send(builder.createCommands());
                        if (!isConnected)
                            Toast.makeText(getBaseContext(), R.string.send_tips_no_connected, Toast.LENGTH_SHORT).show();
                    }
                });
                break;

            case R.id.pressmode:
                startActivity(new Intent(this, PalmActivity.class));
                finish();
                break;

            case R.id.set_btn: // 关于
                SetDialog.createDialog(true,this, getFragmentManager(), new SetDialog.OnSetClickListener() {
                    @Override
                    public void onSetDialogClick(int positon) {
                        if (positon == 0)
                        {
                            PackageManager manager = getPackageManager();
                            String versionName;
                            try {
                                versionName = manager.getPackageInfo(getPackageName(), PackageManager.GET_ACTIVITIES).versionName;
                            } catch (PackageManager.NameNotFoundException e) {
                                e.printStackTrace();
                                versionName = "1.0";
                            }
                            String about = getString(R.string.about_declare, versionName);
                            PromptDialog.create(getBaseContext(), getFragmentManager(), getString(R.string.about_declare_title), Html.fromHtml(about),
                                    null, getString(R.string.dialog_yes), null);
                        }
                        else if (positon == 1)//设置舵机运作速度
                        {
                            SetServoSpeed.create(getBaseContext(), getFragmentManager(), String.valueOf(PalmActivity.m_servoTime),new SetServoSpeed.OnSetSpeedClickListener(){
                                        @Override
                                        public void SetSpeedClick(int time)
                                        {
                                            writeServoSpeed(time);
                                        }
                                    }
                            );
                        }
                        else if(positon == 2)
                        {
                            SetDefaultPressAngle.create(getBaseContext(), getFragmentManager(), new SetDefaultAngle.OnSetDefaultAngleClickListener() {
                                @Override
                                public void SetDefaultAngleClick(boolean status) {
                                    setDefaultPressAngles();
                                    if(status)
                                    {
                                        Toast.makeText(getBaseContext(),R.string.change_sucess,Toast.LENGTH_SHORT).show();
                                    }
                                    else
                                    {
                                        Toast.makeText(getBaseContext(),R.string.change_fail,Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                        }
                        else if(positon == 3)
                        {
                            SetDefaultAngle.create(getBaseContext(), getFragmentManager(), new SetDefaultAngle.OnSetDefaultAngleClickListener() {
                                @Override
                                public void SetDefaultAngleClick(boolean status) {
                                    setDefaultAngles();
                                    if(status)
                                    {
                                        Toast.makeText(getBaseContext(),R.string.change_sucess,Toast.LENGTH_SHORT).show();
                                    }
                                    else
                                    {
                                        Toast.makeText(getBaseContext(),R.string.change_fail,Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                        }
                        else if(positon == 4)
                        {
                           // HelpDialog.create(getBaseContext(),getFragmentManager());
                            startActivity(new Intent(getBaseContext(), HelpActivity.class));
                        }
                    }
                });
                break;
        }
    }

    private void writeServoSpeed(int speed)
    {
        File LanFile = new File(this.getFilesDir(),"config.dat");
        try {
            FileOutputStream fos = new FileOutputStream(LanFile);
            fos.write(("servo speed:"+String.valueOf(speed)).getBytes());
            fos.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    public void setDefaultAngles()
    {
        for(int i = 0;i < 5;i++)
        {
            fingerLoose[i] = PalmActivity.thumbsDefaultArry[i];
        }
    }

    public void setDefaultPressAngles()
    {
        for(int i = 0;i < 5;i++)
        {
            fingerBend[i] = PalmActivity.thumbsPressDefaultArry[i];
        }
    }

    @Override
    public void onDeviceSelected(BluetoothDevice device) {
        LogUtil.i(TAG, "bond state = " + device.getBondState());
        mBluetoothDevice = device;
        bleManager.connect(device);
//        setState(R.string.bluetooth_state_connecting);
        Toast.makeText(this, R.string.bluetooth_state_connecting, Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        int id = v.getId();
        int index = 0;
        switch (id)
        {
            case R.id.square1:
                index = 0;
                break;
            case R.id.square2:
                index = 1;
                break;
            case R.id.square3:
                index = 2;
                break;
            case R.id.square4:
                index = 3;
                break;
            case R.id.square5:
                index = 4;
                break;
        }
        if (event.getAction() == MotionEvent.ACTION_DOWN)
        {
            byte Low = (byte) (fingerBend[index] & 0x00ff);
            byte High = (byte) ((fingerBend[index] >> 8) & 0x00ff);
            PalmActivity.fingersAngle[index] = fingerBend[index];
            ControlCmdSend((byte)(index + 1) , Low, High);
        }
        else if(event.getAction() == MotionEvent.ACTION_UP)
        {
            byte Low = (byte) (fingerLoose[index] & 0x00ff);
            byte High = (byte) ((fingerLoose[index] >> 8) & 0x00ff);
            ControlCmdSend((byte)(index + 1) , Low, High);
            PalmActivity.fingersAngle[index] = fingerLoose[index];
        }
        return false;
    }
    private void ControlCmdSend(byte id,byte Low,byte High)
    {
        byte TimeLow = (byte)(PalmActivity.m_servoTime & 0x00ff);
        byte TimeHigh = (byte) ((PalmActivity.m_servoTime >> 8) & 0x00ff);
        byte[] byteArray = {0x55, 0x55, 0x08, 0x03, 0x01, TimeLow, TimeHigh, id, Low, High};
        ByteCommand.Builder builder = new ByteCommand.Builder();
        builder.addCommand(byteArray, 2);
        bleManager.send(builder.createCommands());
    }

    private void setState(boolean isConnected) {
        LogUtil.i(TAG, "isConnected = " + isConnected);
        if (isConnected) {
            this.isConnected = true;
            btStateBtn.setImageResource(R.drawable.bluetooth_connected);
        } else {
            this.isConnected = false;
            btStateBtn.setImageResource(R.drawable.bluetooth_disconnected);
        }
    }

    class MsgCallBack implements Handler.Callback {

        @Override
        public boolean handleMessage(Message msg) {
            switch (msg.what) {
                case Constants.MessageID.MSG_CONNECT_SUCCEED:
                    LogUtil.i(TAG, "connected ");
//                    setState(R.string.bluetooth_state_connected);
                    Toast.makeText(getBaseContext(), R.string.bluetooth_state_connected, Toast.LENGTH_SHORT).show();
                    setState(true);
                    break;
                case Constants.MessageID.MSG_CONNECT_FAILURE:
                    if (connectTimes < RETRY_TIMES) {
                        connectTimes++;
                        mHandler.sendEmptyMessageDelayed(Constants.MessageID.MSG_CONNECT_RECONNECT, 300);
                    } else {
                        connectTimes = 0;
//                        setState(R.string.bluetooth_state_connect_failure);
                        Toast.makeText(getBaseContext(), R.string.bluetooth_state_connect_failure, Toast.LENGTH_SHORT).show();
                        setState(false);
                    }
                    break;
                case Constants.MessageID.MSG_CONNECT_RECONNECT:
                    LogUtil.i(TAG, "reconnect bluetooth" + mBluetoothDevice.getName() + " " + connectTimes);
                    bleManager.connect(mBluetoothDevice);
                    break;
                case Constants.MessageID.MSG_CONNECT_LOST:
//                    setState(R.string.bluetooth_state_disconnected);
                    Toast.makeText(getBaseContext(), R.string.disconnect_tips_succeed, Toast.LENGTH_SHORT).show();
                    setState(false);
                    break;
                case Constants.MessageID.MSG_SEND_COMMAND:
                    bleManager.send((ByteCommand)msg.obj);
                    Message sendMsg = mHandler.obtainMessage(Constants.MessageID.MSG_SEND_COMMAND, msg.arg1, -1, msg.obj);
                    mHandler.sendMessageDelayed(sendMsg, msg.arg1);
                    break;

                case Constants.MessageID.MSG_SEND_NOT_CONNECT:
                    // Toast.makeText(getActivity(), R.string.send_tips_no_connected, Toast.LENGTH_SHORT).show();
                    break;
            }
            return true;
        }
    }
}
