package com.lobot.opensourceUhand.widget;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import com.lobot.opensourceUhand.R;

/**
 * Created by andy on 2016/6/16.
 */
public class SetDialog extends BaseDialog implements View.OnClickListener,
        AdapterView.OnItemClickListener
{
    public interface OnSetClickListener
    {
        void onSetDialogClick(int action);
    }
    private OnSetClickListener onSetDialogClickListener;
    private FragmentManager fm;
    private boolean fingerUpSetFlag;
    public OnSetClickListener getSetDialogClickListener()
    {
        return onSetDialogClickListener;
    }
    public void setOnDanceClickListener(OnSetClickListener onSetDialogClickListenerr)
    {
        this.onSetDialogClickListener = onSetDialogClickListenerr;
    }
    public static void createDialog(boolean fingerUpSetFlag, Context context, FragmentManager fragmentManager,  OnSetClickListener onSetDialogClickListener)
    {
        SetDialog dialog = new SetDialog();
        dialog.context = context;
        dialog.title = context.getString(R.string.title_set_dialog);
        //dialog.leftBtnText = context.getString(R.string.dialog_cancel);
        //dialog.rightBtnText = context.getString(R.string.dialog_dance_add);
        dialog.fingerUpSetFlag = fingerUpSetFlag;
        dialog.setOnDanceClickListener(onSetDialogClickListener);
        dialog.fm = fragmentManager;
        dialog.show(fragmentManager, "setDialog");
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.layout_set_dialog, container, false);
    }
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);
        ListView listView = (ListView) view.findViewById(R.id.device_item_list);

        String[] contents;
        if(fingerUpSetFlag)
        {
            contents = new String[6];
            contents[2] = getString(R.string.thumbs_angel_press_set);
            contents[3] = getString(R.string.thumbs_angel_set);
            contents[4] = getString(R.string.help_tips);
            contents[5] = getString(R.string.dialog_cancel);
        }
        else
        {
            contents = new String[4];
            contents[2] = getString(R.string.help_tips);
            contents[3] = getString(R.string.dialog_cancel);
        }
        contents[0] = getString(R.string.about);
        contents[1] = getString(R.string.set_servo_speed);


        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, contents);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);
    }
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if (onSetDialogClickListener != null) {
            onSetDialogClickListener.onSetDialogClick(position);
        }
        dismissAllowingStateLoss();
    }

}
