#ifndef _ROBOT_RUN_H_
#define _ROBOT_RUN_H_




void TaskRobotRun(void);

void FullActRun(uint32 actFullnum,uint32 times);//初始化并运行新的动作
void FullActStop(void);




#endif


