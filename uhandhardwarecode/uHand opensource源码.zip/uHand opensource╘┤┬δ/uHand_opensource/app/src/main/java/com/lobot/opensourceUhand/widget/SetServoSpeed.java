package com.lobot.opensourceUhand.widget;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.SeekBar;

import com.lobot.opensourceUhand.PalmActivity;
import com.lobot.opensourceUhand.R;

/**
 * Created by andy on 2016/7/6.
 */
public class SetServoSpeed extends BaseDialog implements DialogInterface.OnClickListener
{
    private EditText speedValue;
    private String speedStrValue;
    private SeekBar setSpeed;
    private FragmentManager fm;
    private int seekbarPos;

    public interface OnSetSpeedClickListener
    {
        void SetSpeedClick(int time);
    }
    private OnSetSpeedClickListener onSetSpeedClickListener;

    public void setOnChangeClickListener(OnSetSpeedClickListener onSetSpeedClickListener) {
        this.onSetSpeedClickListener = onSetSpeedClickListener;
    }

    public static DialogFragment create(Context context, FragmentManager fm,String speedStr,OnSetSpeedClickListener onSetSpeedClickListener)
    {
        SetServoSpeed dialog = new SetServoSpeed();
        dialog.context = context;
        dialog.title = context.getString(R.string.set_servo_speed);
        dialog.leftBtnText = context.getString(R.string.dialog_cancel);
        dialog.rightBtnText = context.getString(R.string.dialog_yes);
        dialog.speedStrValue = speedStr;
        dialog.fm = fm;
        dialog.onSetSpeedClickListener = onSetSpeedClickListener;
        dialog.show(fm,"SetServoSpeed");
        return dialog;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setOnClickListener(this);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.layout_set_servo_speed, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        speedValue = (EditText) view.findViewById(R.id.angeValueEdit);
        if (!TextUtils.isEmpty(speedStrValue))
            speedValue.setText(speedStrValue);
        speedValue.setSelection(speedValue.length());
        setSpeed = (SeekBar)view.findViewById(R.id.seekbarSetSpeed);
        setSpeed.setProgress(PalmActivity.m_servoTime-20);
        setSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
            {
                seekbarPos = progress;
                speedValue.setText(String.valueOf(progress+20));
                speedValue.setSelection(speedValue.length());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar)
            {
            }
        });
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        switch (which) {

            case BUTTON_POSITIVE:
                String speed = speedValue.getText().toString();
                if(speed.length() != 0)
                {
                    int temp = Integer.parseInt(speed);
                    if(temp < 20)
                    {
                        PalmActivity.m_servoTime = 20;
                    }
                    else if(temp > 2000)
                    {
                        PalmActivity.m_servoTime = 2000;
                    }
                    else
                        PalmActivity.m_servoTime = temp;

                }
                setSpeed.setProgress(PalmActivity.m_servoTime-20);
                onSetSpeedClickListener.SetSpeedClick(PalmActivity.m_servoTime);
                break;
            case BUTTON_NEGATIVE:
                break;
        }
    }
}

