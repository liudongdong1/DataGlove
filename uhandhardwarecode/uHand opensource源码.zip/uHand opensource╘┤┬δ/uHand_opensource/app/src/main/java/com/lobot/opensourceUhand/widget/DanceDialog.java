package com.lobot.opensourceUhand.widget;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.lobot.opensourceUhand.db.CommandDAO;
import com.lobot.opensourceUhand.model.CommandModel;
import com.lobot.opensourceUhand.R;

import java.util.List;

/**
 * 跳舞对话框
 * Created by hejie on 2015/8/23.
 */
public class DanceDialog extends BaseDialog implements View.OnClickListener, DialogInterface.OnClickListener,
        AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener {

    public interface OnDanceClickListener {
        /**
         * 点击跳舞动作
         *
         * @param action 动作内容
         */
        void onDanceClick(int action);
    }

    private List<CommandModel> danceList;
    private OnDanceClickListener onDanceClickListener;
    private FragmentManager fm;
    private int type;
    static private int DBType;//true为机械手臂 false为双足

    public OnDanceClickListener getOnDanceClickListener() {
        return onDanceClickListener;
    }

    public void setOnDanceClickListener(OnDanceClickListener onDanceClickListener) {
        this.onDanceClickListener = onDanceClickListener;
    }

    public static void createDialog(Context context, FragmentManager fragmentManager, int type, int DB_Type,OnDanceClickListener onDanceClickListener) {
        DanceDialog dialog = new DanceDialog();
        dialog.context = context;
        dialog.type = type;
        if (type == CommandModel.TYPE_DANCE)
            dialog.title = context.getString(R.string.dialog_dance_title);
        else if (type == CommandModel.TYPE_ACTION)
            dialog.title = context.getString(R.string.dialog_action_title);
        dialog.leftBtnText = context.getString(R.string.dialog_cancel);
        dialog.rightBtnText = context.getString(R.string.dialog_dance_add);
        dialog.setOnDanceClickListener(onDanceClickListener);
        dialog.fm = fragmentManager;
        dialog.show(fragmentManager, "danceDialog");
        DBType = DB_Type;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setOnClickListener(this);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.layout_dialog_dance, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ListView listView = (ListView) view.findViewById(R.id.device_list);
        CommandDAO dao = new CommandDAO(getActivity(),DBType);


        danceList = dao.query(type);
        String[] contents = new String[danceList.size()];
        for (int i = 0; i < danceList.size(); i++) {
            contents[i] = danceList.get(i).getTitle();
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, contents);
//        danceAdapter = new DanceAdapter(dao.query());
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);
        listView.setOnItemLongClickListener(this);
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        if (BUTTON_POSITIVE == which) {
            AddDanceDialog.create(context, fm, type,DBType);
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if (onDanceClickListener != null) {
            onDanceClickListener.onDanceClick(danceList.get(position).getAction());
        }
        dismissAllowingStateLoss();
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
        final CommandModel dance = danceList.get(position);
        if (!dance.isCanEdit()) {
            Toast.makeText(context, R.string.dialog_dance_add_can_edit, Toast.LENGTH_SHORT).show();
            return false;
        }
        PromptDialog.create(context, fm, getString(R.string.dialog_dance_choice),
                getString(R.string.dialog_dance_choice_content), getString(R.string.dialog_dance_delete),
                getString(R.string.dialog_dance_update), new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        if (BUTTON_NEGATIVE == which) {
                            CommandDAO dao = new CommandDAO(context,DBType);
                            if (!dao.delete(dance.getId())) {
                                Toast.makeText(context, R.string.dialog_dance_add_failure, Toast.LENGTH_SHORT).show();
                            }
                        } else if (BUTTON_POSITIVE == which) {
                            FragmentManager fm = ((DialogFragment) dialog).getActivity().getFragmentManager();
                            AddDanceDialog.create(context, fm, type, dance.getId(), dance.getTitle(), String.valueOf(dance.getAction()),DBType);
                        }
                    }
                });
        dismissAllowingStateLoss();
        return false;
    }

}
