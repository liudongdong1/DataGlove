package com.lobot.opensourceUhand;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.Html;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.lobot.opensourceUhand.R;
import com.lobot.opensourceUhand.commen.Constants;
import com.lobot.opensourceUhand.connect.BLEManager;
import com.lobot.opensourceUhand.connect.BLEService;
import com.lobot.opensourceUhand.model.ByteCommand;
import com.lobot.opensourceUhand.model.CommandModel;
import com.lobot.opensourceUhand.uitls.BluetoothUtils;
import com.lobot.opensourceUhand.uitls.LogUtil;
import com.lobot.opensourceUhand.widget.DanceDialog;
import com.lobot.opensourceUhand.widget.PromptDialog;
import com.lobot.opensourceUhand.widget.SearchDialog;
import com.lobot.opensourceUhand.widget.SetDialog;
import com.lobot.opensourceUhand.widget.SetServoSpeed;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.Timer;
import java.util.TimerTask;
import com.lobot.opensourceUhand.widget.VerticalSeekBar;

public class PalmActivity extends Activity implements SearchDialog.OnDeviceSelectedListener {

    private boolean isConnected = false;
    private boolean confirm;
    private Handler mHandler;
    private ImageButton btStateBtn;
    private static final int RETRY_TIMES = 3;
    public static BluetoothAdapter mBluetoothAdapter = null;
    public static BLEManager bleManager;
    public static BluetoothDevice mBluetoothDevice;
    private static final int REQUEST_FINE_LOCATION = 0;


    private TextView fingersText[] = new TextView[5];

    public static int fingersAngle[] = new int[5];

    public static int m_servoTime = 200;

    private boolean resetServoFlag = false;

    private boolean _50msFlag = true;
    Timer timer = new Timer();
    public static int thumbsDefaultArry[] = new int[5];
    public static int thumbsPressDefaultArry[] = new int[5];
    /**
     * 连接次数
     */
    private int connectTimes;

    public static int MIN_ANGLE = 900;
    public static int MAX_ANGLE = 2000;

    private VerticalSeekBar[] seekBars = new VerticalSeekBar[5];
    private static final String TAG = PalmActivity.class.getSimpleName();
    public static ServiceConnection mConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            LogUtil.i(TAG, "BLE Service connected");
            BLEService bleService = ((BLEService.BLEBinder) service).getService();
            BLEManager.getInstance().init(bleService);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            LogUtil.w(TAG, "BLE Service disconnected");
            BLEManager.getInstance().destroy();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_palm);

        if (!BluetoothUtils.isSupport(BluetoothAdapter.getDefaultAdapter())) {
            Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
            finish();
        }

        mHandler = new Handler(new MsgCallBack());
        SetTimerTask50ms();
        Intent intent = new Intent(this, BLEService.class);
        startService(intent);
        bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
        BLEManager.getInstance().register(this);
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        connectTimes = 0;

        btStateBtn = (ImageButton) findViewById(R.id.bluetooth_btn);

        fingersText[0] = (TextView) findViewById(R.id.finger1_text);
        fingersText[1] = (TextView) findViewById(R.id.finger2_text);
        fingersText[2] = (TextView) findViewById(R.id.finger3_text);
        fingersText[3] = (TextView) findViewById(R.id.finger4_text);
        fingersText[4] = (TextView) findViewById(R.id.finger5_text);

        seekBars[0] = (VerticalSeekBar) findViewById(R.id.seekbar1);
        seekBars[1] = (VerticalSeekBar) findViewById(R.id.seekbar2);
        seekBars[2] = (VerticalSeekBar) findViewById(R.id.seekbar3);
        seekBars[3] = (VerticalSeekBar) findViewById(R.id.seekbar4);
        seekBars[4] = (VerticalSeekBar) findViewById(R.id.seekbar5);


        if (mBluetoothAdapter == null) {
            Toast.makeText(this, R.string.open_bluetooth_unsupported, Toast.LENGTH_LONG).show();
        } else {
            if (!mBluetoothAdapter.isEnabled()) {
                PromptDialog.create(this, getFragmentManager(), getString(R.string.open_bluetooth_title),
                        getString(R.string.open_bluetooth_content), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (which == DialogInterface.BUTTON_POSITIVE) {
                                    mBluetoothAdapter.enable();
                                }
                            }
                        });
            }
        }
        for (int i = 0; i < fingersAngle.length; i++) {
            fingersAngle[i] = 1500;
        }
        mayRequestLocation();
        initSeekBars();
    }

    @Override
    public void onResume() {
        super.onResume();
        bleManager = BLEManager.getInstance();
        isConnected = bleManager.isConnected();
        bleManager.setHandler(mHandler);
        LogUtil.i(TAG, "onResume isConnected= " + isConnected);
        if (isConnected)
            btStateBtn.setImageResource(R.drawable.bluetooth_connected);
        else
            btStateBtn.setImageResource(R.drawable.bluetooth_disconnected);
        for (int i = 0; i < fingersText.length; i++) {
            fingersText[i].setText(String.valueOf(fingersAngle[i]));
        }
        readServoSpeed();
        ReadthumbsDefault();
        ReadthumbsPressDefault();
    }

    @Override
    protected void onDestroy() {
        LogUtil.i(TAG, "PalmActivityClose");
        unbindService(mConnection);
        BLEManager.getInstance().unregister(this);
        super.onDestroy();
    }


    private void initSeekBars()
    {
        seekBars[0].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(_50msFlag && !resetServoFlag)
                {
                    ControlCmdSend(1,2000 - progress);
                    fingersText[0].setText(String.valueOf(2000 - progress));
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if(_50msFlag && !resetServoFlag)
                {
                    ControlCmdSend(1,2000 - seekBar.getProgress());
                    fingersText[0].setText(String.valueOf(2000 - seekBar.getProgress()));
                }
            }
        });

        seekBars[1].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(_50msFlag && !resetServoFlag)
                {
                    ControlCmdSend(2,progress + 900);
                    fingersText[1].setText(String.valueOf(progress + 900));
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if(_50msFlag && !resetServoFlag)
                {
                    ControlCmdSend(2,seekBar.getProgress() + 900);
                    fingersText[1].setText(String.valueOf(seekBar.getProgress() + 900));
                }
            }
        });

        seekBars[2].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(_50msFlag && !resetServoFlag)
                {
                    ControlCmdSend(3,progress + 900);
                    fingersText[2].setText(String.valueOf(progress + 900));
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if(_50msFlag && !resetServoFlag)
                {
                    ControlCmdSend(3,seekBar.getProgress() + 900);
                    fingersText[2].setText(String.valueOf(seekBar.getProgress() + 900));
                }
            }
        });


        seekBars[3].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(_50msFlag && !resetServoFlag)
                {
                    ControlCmdSend(4,progress + 900);
                    fingersText[3].setText(String.valueOf(progress + 900));
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if(_50msFlag && !resetServoFlag)
                {
                    ControlCmdSend(4,seekBar.getProgress() + 900);
                    fingersText[3].setText(String.valueOf(seekBar.getProgress() + 900));
                }
            }
        });


        seekBars[4].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(_50msFlag && !resetServoFlag)
                {
                    ControlCmdSend(5,2000 - seekBar.getProgress());
                    fingersText[4].setText(String.valueOf(2000 - progress));
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if(_50msFlag && !resetServoFlag)
                {
                    ControlCmdSend(5,2000 - seekBar.getProgress());
                    fingersText[4].setText(String.valueOf(2000 - seekBar.getProgress()));
                }
            }
        });
    }

    private void mayRequestLocation()
    {
        if(mBluetoothAdapter.isEnabled())
        {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            {
                int checkCallPhonePermission = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION);
                if(checkCallPhonePermission != PackageManager.PERMISSION_GRANTED)
                {
                    if(ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_COARSE_LOCATION))
                    {

                    }
                    ActivityCompat.requestPermissions(this ,new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},REQUEST_FINE_LOCATION);
                    return;
                }
                else
                {

                }
            }
            else
            {

            }
        }
    }

    private void readServoSpeed()
    {
        File readSpeed = new File(getFilesDir(),"config.dat");
        if(readSpeed.exists())
        {
            try
            {
                FileInputStream fis = new FileInputStream(readSpeed);
                BufferedReader br = new BufferedReader(new InputStreamReader(fis));
                String text = br.readLine();
                String[] sourceStrArray = text.split(":");
                if(sourceStrArray.length == 2)
                {
                    try {
                        int temp = Integer.parseInt(sourceStrArray[1]);
                        if(temp >= 20 && temp <= 2000)
                        {
                            m_servoTime = temp;
                        }
                        else
                        {
                            writeServoSpeed(m_servoTime);
                        }
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                        writeServoSpeed(m_servoTime);
                    }
                }

            }
            catch (Exception e)
            {
                e.printStackTrace();
                writeServoSpeed(m_servoTime);
            }

        }
        else
        {
            writeServoSpeed(m_servoTime);
        }
    }

    private void writeServoSpeed(int speed)
    {
        File LanFile = new File(this.getFilesDir(),"config.dat");
        try {
            FileOutputStream fos = new FileOutputStream(LanFile);
            fos.write(("servo speed:"+String.valueOf(speed)).getBytes());
            fos.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

     private void ReadthumbsDefault()
    {
        File ReadLan = new File(this.getFilesDir(),"servo.dat");
        if(ReadLan.exists())
        {
            try{
                FileInputStream fis = new FileInputStream(ReadLan);
                BufferedReader br = new BufferedReader(new InputStreamReader(fis));
                String text = br.readLine();
                String servoNum[] = text.split("&&");
                for(int i = 0;i<servoNum.length;i++)
                {
                    thumbsDefaultArry[i] = Integer.valueOf(servoNum[i]).intValue();
                }
                fis.close();
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        else
        {
            //写入到内部存储文件中
            thumbsDefaultArry[0] = 1100;
            thumbsDefaultArry[1] = 1800;
            thumbsDefaultArry[2] = 1800;
            thumbsDefaultArry[3] = 1800;
            thumbsDefaultArry[4] = 1100;
            try {
                FileOutputStream fos = new FileOutputStream(ReadLan);
                fos.write(("1100&&1800&&1800&&1800&&1100").getBytes());
                fos.close();
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    private void ReadthumbsPressDefault()
    {
        File ReadLan = new File(this.getFilesDir(),"press.dat");
        if(ReadLan.exists())
        {
            try{
                FileInputStream fis = new FileInputStream(ReadLan);
                BufferedReader br = new BufferedReader(new InputStreamReader(fis));
                String text = br.readLine();
                String servoNum[] = text.split("&&");
                for(int i = 0;i<servoNum.length;i++)
                {
                    thumbsPressDefaultArry[i] = Integer.valueOf(servoNum[i]).intValue();
                }
                fis.close();
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        else
        {
            //写入到内部存储文件中
            thumbsPressDefaultArry[0] = 1500;
            thumbsPressDefaultArry[1] = 1400;
            thumbsPressDefaultArry[2] = 1400;
            thumbsPressDefaultArry[3] = 1400;
            thumbsPressDefaultArry[4] = 1500;
            try {
                FileOutputStream fos = new FileOutputStream(ReadLan);
                fos.write(("1500&&1400&&1400&&1400&&1500").getBytes());
                fos.close();
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    private void ControlCmdSend(int id,int positon)
    {
        byte TimeLow = (byte)(m_servoTime & 0x00ff);
        byte TimeHigh = (byte) ((m_servoTime >> 8) & 0x00ff);
        byte Low = (byte)(positon & 0x00ff);
        byte High = (byte)((positon >> 8) & 0x00ff);
        byte[] byteArray = {0x55, 0x55, 0x08, 0x03, 0x01, TimeLow, TimeHigh, (byte) id, Low, High};
        ByteCommand.Builder builder = new ByteCommand.Builder();
        builder.addCommand(byteArray, 20);
        bleManager.send(builder.createCommands());
    }


    public void onClick(View v) {
        int id = v.getId();
        int i;
        switch (id) {
            case R.id.bluetooth_btn: // 蓝牙
                mayRequestLocation();
                if (mBluetoothAdapter.isEnabled()) {
                    if (isConnected) {
                        PromptDialog.create(this, getFragmentManager(), getString(R.string.disconnect_tips_title),
                                getString(R.string.disconnect_tips_connect), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        if (DialogInterface.BUTTON_POSITIVE == which) {
                                            bleManager.stop();
                                        }
                                    }
                                });
                    } else {
                        SearchDialog.createDialog(getFragmentManager(), this);
                    }
                } else {
                    Toast.makeText(this, R.string.tips_open_bluetooth, Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
                }
                break;

            case R.id.stop_btn://复位舵机角度
                resetServoFlag = true;
                bleManager.removeAll();
                for (i = 0; i < fingersAngle.length; i++) {
                    fingersAngle[i] = 1500;
                    fingersText[i].setText(String.valueOf(fingersAngle[i]));
                    seekBars[i].setProgresEx(600);
                    ControlCmdSend(i+1,1500);
                }

                resetServoFlag = false;
                if (!isConnected)
                    Toast.makeText(this, R.string.send_tips_no_connected, Toast.LENGTH_SHORT).show();
                break;

            case R.id.seftdefine_btn:
                DanceDialog.createDialog(this, getFragmentManager(), CommandModel.TYPE_ACTION, 1, new DanceDialog.OnDanceClickListener() {
                    @Override
                    public void onDanceClick(int action) {
                        byte[] byteArray = {0x55, 0x55, 0x05, 0x06, 0x00, 0x01, 0x00};
                        byteArray[4] = (byte) (action & 0xff);
                        ByteCommand.Builder builder = new ByteCommand.Builder();
                        builder.addCommand(byteArray, 100);
                        bleManager.send(builder.createCommands());
                        if (!isConnected)
                            Toast.makeText(getBaseContext(), R.string.send_tips_no_connected, Toast.LENGTH_SHORT).show();
                    }
                });
                break;

            case R.id.pressmode:
                startActivity(new Intent(this, FingerPressActivity.class));
                break;

            case R.id.set_btn: // 关于
                SetDialog.createDialog(false,this, getFragmentManager(), new SetDialog.OnSetClickListener() {
                    @Override
                    public void onSetDialogClick(int positon) {
                        if (positon == 0)
                        {
                            PackageManager manager = getPackageManager();
                            String versionName;
                            try {
                                versionName = manager.getPackageInfo(getPackageName(), PackageManager.GET_ACTIVITIES).versionName;
                            } catch (PackageManager.NameNotFoundException e) {
                                e.printStackTrace();
                                versionName = "1.0";
                            }
                            String about = getString(R.string.about_declare, versionName);
                            PromptDialog.create(getBaseContext(), getFragmentManager(), getString(R.string.about_declare_title), Html.fromHtml(about),
                                    null, getString(R.string.dialog_yes), null);
                        }
                        else if (positon == 1)//设置舵机运作速度
                        {
                            SetServoSpeed.create(getBaseContext(), getFragmentManager(), String.valueOf(m_servoTime),new SetServoSpeed.OnSetSpeedClickListener(){
                                        @Override
                                        public void SetSpeedClick(int time)
                                        {
                                            writeServoSpeed(time);
                                        }
                                    }
                            );
                        }
                        else if(positon == 2)
                        {
                           // HelpDialog.create(getBaseContext(),getFragmentManager());
                            startActivity(new Intent(getBaseContext(), HelpActivity.class));
                        }
                     }
                });
                break;
        }
    }

    private void SetTimerTask50ms()//设置50ms定时
    {
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Message message = new Message();
                message.what = Constants.MessageID.MSG_SEND_50ms;
                mHandler.sendMessage(message);
            }
        }, 0, 50);
    }

    private void setState(boolean isConnected) {
        LogUtil.i(TAG, "isConnected = " + isConnected);
        if (isConnected) {
            this.isConnected = true;
            btStateBtn.setImageResource(R.drawable.bluetooth_connected);
        } else {
            this.isConnected = false;
            btStateBtn.setImageResource(R.drawable.bluetooth_disconnected);
        }
    }

    @Override
    public void onDeviceSelected(BluetoothDevice device) {
        LogUtil.i(TAG, "bond state = " + device.getBondState());
        mBluetoothDevice = device;
        bleManager.connect(device);
//        setState(R.string.bluetooth_state_connecting);
        Toast.makeText(this, R.string.bluetooth_state_connecting, Toast.LENGTH_SHORT).show();
    }

    class MsgCallBack implements Handler.Callback {

        @Override
        public boolean handleMessage(Message msg) {
            switch (msg.what) {
                case Constants.MessageID.MSG_CONNECT_SUCCEED:
                    LogUtil.i(TAG, "connected ");
//                    setState(R.string.bluetooth_state_connected);
                    Toast.makeText(getBaseContext(), R.string.bluetooth_state_connected, Toast.LENGTH_SHORT).show();
                    setState(true);
                    break;
                case Constants.MessageID.MSG_CONNECT_FAILURE:
                    if (connectTimes < RETRY_TIMES) {
                        connectTimes++;
                        mHandler.sendEmptyMessageDelayed(Constants.MessageID.MSG_CONNECT_RECONNECT, 300);
                    } else {
                        connectTimes = 0;
//                        setState(R.string.bluetooth_state_connect_failure);
                        Toast.makeText(getBaseContext(), R.string.bluetooth_state_connect_failure, Toast.LENGTH_SHORT).show();
                        setState(false);
                    }
                    break;
                case Constants.MessageID.MSG_CONNECT_RECONNECT:
                    LogUtil.i(TAG, "reconnect bluetooth" + mBluetoothDevice.getName() + " " + connectTimes);
                    bleManager.connect(mBluetoothDevice);
                    break;
                case Constants.MessageID.MSG_CONNECT_LOST:
//                    setState(R.string.bluetooth_state_disconnected);
                    Toast.makeText(getBaseContext(), R.string.disconnect_tips_succeed, Toast.LENGTH_SHORT).show();
                    setState(false);
                    break;
                case Constants.MessageID.MSG_SEND_COMMAND:
                    bleManager.send((ByteCommand)msg.obj);
                    Message sendMsg = mHandler.obtainMessage(Constants.MessageID.MSG_SEND_COMMAND, msg.arg1, -1, msg.obj);
                    mHandler.sendMessageDelayed(sendMsg, msg.arg1);
                    break;

                case Constants.MessageID.MSG_SEND_NOT_CONNECT:
                    // Toast.makeText(getActivity(), R.string.send_tips_no_connected, Toast.LENGTH_SHORT).show();
                    break;

                case Constants.MessageID.MSG_SEND_50ms:
                    _50msFlag = !_50msFlag;
                    break;
            }
            return true;
        }
    }
    @Override
    public void onBackPressed() {
        if (BLEManager.getInstance().isConnected()) {
            PromptDialog.create(this, getFragmentManager(), getString(R.string.exit_tips_title),
                    getString(R.string.exit_tips_content), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (DialogInterface.BUTTON_POSITIVE == which) {
                                BLEManager.getInstance().stop();
                                PalmActivity.super.onBackPressed();
                                android.os.Process.killProcess(android.os.Process.myPid());
                            }
                        }
                    });
        } else {
            if (!confirm) {
                confirm = true;
                Toast.makeText(this, R.string.exit_remind, Toast.LENGTH_SHORT).show();
                Timer timer = new Timer();
                timer.schedule(new TimerTask() {

                    @Override
                    public void run() {
                        confirm = false;
                    }
                }, 2000);
            } else {
                Intent intent = new Intent(this, BLEService.class);
                stopService(intent);
                BLEManager.getInstance().destroy();
                super.onBackPressed();
                android.os.Process.killProcess(android.os.Process.myPid());
            }
        }
    }
}
