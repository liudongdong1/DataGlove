package com.lobot.opensourceUhand.model;

/**
 * 指令模型类
 * Created by hejie on 2015/8/23.
 */
public class CommandModel {

    private int id;
    private String title;
    private int action;
    private boolean canEdit;
    private int type;

    /** 指令类型，舞蹈 */
    public static final int TYPE_DANCE = 0;
    /** 指令类型，自定义动作 */
    public static final int TYPE_ACTION = 1;

    public CommandModel() {
    }

    public CommandModel(String title, int action, boolean canEdit, int type) {
        this.title = title;
        this.action = action;
        this.canEdit = canEdit;
        this.type = type;
    }

    public CommandModel(int id, String title, int action, boolean canEdit, int type) {
        this.id = id;
        this.title = title;
        this.action = action;
        this.canEdit = canEdit;
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getAction() {
        return action;
    }

    public void setAction(int action) {
        this.action = action;
    }

    public boolean isCanEdit() {
        return canEdit;
    }

    public void setCanEdit(boolean canEdit) {
        this.canEdit = canEdit;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
