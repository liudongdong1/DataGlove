package com.lobot.opensourceUhand.widget;

import android.content.Context;
import android.content.DialogInterface;
import android.app.FragmentManager;
import android.app.DialogFragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.lobot.opensourceUhand.PalmActivity;
import com.lobot.opensourceUhand.R;

import java.io.File;
import java.io.FileOutputStream;

/**
 * Created by andy on 2017/4/17.
 */

public class SetDefaultAngle extends BaseDialog implements DialogInterface.OnClickListener{
    private FragmentManager fm;
    private EditText position1;
    private EditText position2;
    private EditText position3;
    private EditText position4;
    private EditText position5;

    public interface  OnSetDefaultAngleClickListener
    {
        void SetDefaultAngleClick(boolean status);
    }
    private OnSetDefaultAngleClickListener onSetDefaultAngleClickListener;

    public void setOnDefaultAngleClickListener(OnSetDefaultAngleClickListener onSetDefaultAngleClickListener) {
        this.onSetDefaultAngleClickListener = onSetDefaultAngleClickListener;
    }

    public static DialogFragment create(Context context, FragmentManager fm , OnSetDefaultAngleClickListener onSetDefaultAngleClickListener)
    {
        SetDefaultAngle dialog = new SetDefaultAngle();
        dialog.context = context;
        dialog.title = context.getString(R.string.thumbs_angel_set);
        dialog.leftBtnText = context.getString(R.string.dialog_cancel);
        dialog.rightBtnText = context.getString(R.string.dialog_yes);
        dialog.fm = fm;
        dialog.show(fm,"SetDefaultAngle");
        dialog.setOnDefaultAngleClickListener(onSetDefaultAngleClickListener);
        return dialog;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setOnClickListener(this);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.layout_set_default_angle, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        position1 = (EditText)view.findViewById(R.id.position1_num);
        position2 = (EditText)view.findViewById(R.id.position2_num);
        position3 = (EditText)view.findViewById(R.id.position3_num);
        position4 = (EditText)view.findViewById(R.id.position4_num);
        position5 = (EditText)view.findViewById(R.id.position5_num);

        position1.setText(String.valueOf(PalmActivity.thumbsDefaultArry[0]));
        position2.setText(String.valueOf(PalmActivity.thumbsDefaultArry[1]));
        position3.setText(String.valueOf(PalmActivity.thumbsDefaultArry[2]));
        position4.setText(String.valueOf(PalmActivity.thumbsDefaultArry[3]));
        position5.setText(String.valueOf(PalmActivity.thumbsDefaultArry[4]));

        position1.setSelection(position1.length());
        position2.setSelection(position2.length());
        position3.setSelection(position3.length());
        position4.setSelection(position4.length());
        position5.setSelection(position5.length());
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        switch (which) {
            case DialogInterface.BUTTON_POSITIVE:
                onSetDefaultAngleClickListener.SetDefaultAngleClick(SaveDefaultAngleFile());
                break;
            case DialogInterface.BUTTON_NEGATIVE:
                break;
        }
    }

    private boolean SaveDefaultAngleFile()
    {
        //写入到内部存储文件中
        File ReadLan = new File(getActivity().getFilesDir(),"servo.dat");
        Boolean dataStatus = checkInput();
        try {
            FileOutputStream fos = new FileOutputStream(ReadLan);
            fos.write((position1.getText().toString()+"&&"+position2.getText().toString()+"&&"+
                    position3.getText().toString()+"&&"+position4.getText().toString()+"&&"+
                    position5.getText().toString()).getBytes());
            fos.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return false;
        }
        return dataStatus;
    }

    private boolean  checkInput()
    {
        boolean value = true;
        int getValue;
        if(position1.getText().toString().length() > 0)
        {
            getValue = Integer.valueOf(position1.getText().toString());
            if(getValue >= PalmActivity.MIN_ANGLE && getValue <= PalmActivity.MAX_ANGLE)
            {
                PalmActivity.thumbsDefaultArry[0] = getValue;
            }
            else
            {
                value = false;
            }
        }
        else
        {
            position1.setText(String.valueOf(PalmActivity.thumbsDefaultArry[0]));
            value = false;
        }

        if(position2.getText().toString().length() > 0)
        {
            getValue = Integer.valueOf(position2.getText().toString());
            if(getValue >= PalmActivity.MIN_ANGLE && getValue <= PalmActivity.MAX_ANGLE)
            {
                PalmActivity.thumbsDefaultArry[1] = getValue;
            }
            else
            {
                value = false;
            }
        }
        else
        {
            position2.setText(String.valueOf(PalmActivity.thumbsDefaultArry[1]));
            value = false;
        }

        if(position3.getText().toString().length() > 0)
        {
            getValue = Integer.valueOf(position3.getText().toString());
            if(getValue >= PalmActivity.MIN_ANGLE && getValue <= PalmActivity.MAX_ANGLE)
            {
                PalmActivity.thumbsDefaultArry[2] = getValue;
            }
            else
            {
                value = false;
            }
        }
        else
        {
            position3.setText(String.valueOf(PalmActivity.thumbsDefaultArry[2]));
            value = false;
        }

        if(position4.getText().toString().length() > 0)
        {
            getValue = Integer.valueOf(position4.getText().toString());
            if(getValue >= PalmActivity.MIN_ANGLE && getValue <= PalmActivity.MAX_ANGLE)
            {
                PalmActivity.thumbsDefaultArry[3] = getValue;
            }
            else
            {
                value = false;
            }
        }
        else
        {
            position4.setText(String.valueOf(PalmActivity.thumbsDefaultArry[3]));
            value = false;
        }

        if(position5.getText().toString().length() > 0)
        {
            getValue = Integer.valueOf(position5.getText().toString());
            if(getValue >= PalmActivity.MIN_ANGLE && getValue <= PalmActivity.MAX_ANGLE)
            {
                PalmActivity.thumbsDefaultArry[4] = getValue;
            }
            else
            {
                value = false;
            }
        }
        else
        {
            position5.setText(String.valueOf(PalmActivity.thumbsDefaultArry[4]));
            value = false;
        }
        return value;
    }
}
