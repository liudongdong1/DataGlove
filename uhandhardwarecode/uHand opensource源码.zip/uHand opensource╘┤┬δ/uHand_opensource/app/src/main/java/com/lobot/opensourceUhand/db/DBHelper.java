package com.lobot.opensourceUhand.db;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.lobot.opensourceUhand.uitls.LogUtil;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * SQLite数据库帮助类
 * Created by hejie on 2015/8/27.
 */
public class DBHelper extends SQLiteOpenHelper {

    private static final String TAG = "DBHelper";
    public static final String DB_NAME = "robot";
    public static final String DB_NAME_DOUBLE_FEET = "doublefeet";
    public static final int DB_VERSION = 3;
    public static final String TABLE_NAME_COMMAND = "command";
    public static final String TABLE_NAME_VOICE_COMMAND = "voice_command";

    public static final String[] strDb = new String[]{"doublefeet.db","robot.db"};
    private Context context;

    public DBHelper(Context context, SQLiteDatabase.CursorFactory factory,int dbtype) {
        super(context, strDb[dbtype], factory, DB_VERSION);
        this.context = context;
      //  if (!isTableExist(TABLE_NAME_COMMAND) || !isTableExist(TABLE_NAME_VOICE_COMMAND)){
      //      copyDBFile();
       //     getWritableDatabase().setVersion(DB_VERSION);
       // }

        firstRun();
    }

    private void firstRun() {
        SharedPreferences sharedPreferences = context.getSharedPreferences("FirstRun", 0);
        Boolean first_run = sharedPreferences.getBoolean("First", true);
        if (first_run) {
            sharedPreferences.edit().putBoolean("First", false).commit();
            copyDBFile();
            getWritableDatabase().setVersion(DB_VERSION);
        } else {

        }
    }

    protected boolean isTableExist(String tableName) {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select Count(*) from sqlite_master where type=\"table\" and name=\""
                + tableName + "\"";
        Cursor cursor = db.rawQuery(sql, null);
        LogUtil.i(TAG, "isClosed = " + cursor.isClosed());
        LogUtil.i(TAG, "count = " + cursor.getCount());
        if (cursor.moveToFirst()) {
            int count = cursor.getInt(0);
            LogUtil.i(TAG, "check table count = " + count);
            if (count > 0)
                return true;
        }
        cursor.close();
        return false;
    }


    /**
     * 从asset目录拷贝DB文件到数据库目录下
     */
    protected void copyDBFile() {
        LogUtil.i(TAG, "copy DB File " + getDatabaseName());
        InputStream dbIs = null;
        FileOutputStream desOs = null;
        try {
            dbIs = context.getAssets().open(getDatabaseName());
            File desDir = context.getDatabasePath(getDatabaseName());
            desOs = new FileOutputStream(desDir);
            if (!desDir.exists()) {
                desDir.mkdirs();
            }
            byte[] buffer = new byte[8192];
            int count;
            while ((count = dbIs.read(buffer)) > 0) {
                desOs.write(buffer, 0, count);
                desOs.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (dbIs != null)
                    dbIs.close();
                if (desOs != null)
                    desOs.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        LogUtil.d(TAG, "oldVersion = " + oldVersion + ",  newVersion = " + newVersion);
//        if (newVersion > oldVersion) { // 版本更新
//            copyDBFile();
//            db.setVersion(DB_VERSION);
//        }

    }
}
