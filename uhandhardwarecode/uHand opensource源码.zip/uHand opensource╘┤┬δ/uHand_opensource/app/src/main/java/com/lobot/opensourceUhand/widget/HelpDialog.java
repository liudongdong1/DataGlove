package com.lobot.opensourceUhand.widget;

import android.app.DialogFragment;
import android.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.lobot.opensourceUhand.R;

/**
 * Created by andy on 2017/4/19.
 */

public class HelpDialog extends BaseDialog implements DialogInterface.OnClickListener{
    private FragmentManager fm;
    public static DialogFragment create(Context context, FragmentManager fm)
    {
        HelpDialog dialog = new HelpDialog();
        dialog.context = context;
        dialog.title = context.getString(R.string.faq);
        dialog.rightBtnText = context.getString(R.string.dialog_yes);
        dialog.fm = fm;
        dialog.show(fm,"HelpDialog");
        return dialog;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setOnClickListener(this);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.layout_help_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        switch (which) {
            case DialogInterface.BUTTON_POSITIVE:
                break;
            case DialogInterface.BUTTON_NEGATIVE:
                break;
        }
    }
}
