package com.lobot.opensourceUhand.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.lobot.opensourceUhand.model.CommandModel;
import com.lobot.opensourceUhand.uitls.LogUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 指令数据操作类
 * Created by hejie on 2015/8/27.
 */
public class CommandDAO {

    private DBHelper dbHelper;

    public CommandDAO(Context context,int DBtype) {
        dbHelper = new DBHelper(context,null,DBtype);
//        LogUtil.i(DBHelper.TABLE_NAME_COMMAND, "dbHelper = " + dbHelper);
//        LogUtil.i(DBHelper.TABLE_NAME_COMMAND, "db = " + dbHelper.getReadableDatabase());
//        if (!dbHelper.isTableExist(DBHelper.TABLE_NAME_COMMAND, dbHelper.getReadableDatabase())) {
//            dbHelper.copyDBFile();
//        }
    }

    public List<CommandModel> query(int type) {
        List<CommandModel> list = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DBHelper.TABLE_NAME_COMMAND, null, "type=?", new String[]{String.valueOf(type)}, null, null, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            int id = cursor.getInt(cursor.getColumnIndex("id"));
            String title = cursor.getString(cursor.getColumnIndex("title"));
            int action = cursor.getInt(cursor.getColumnIndex("action"));
            boolean canEdit = cursor.getInt(cursor.getColumnIndex("can_edit")) != 0;
            CommandModel dance = new CommandModel(id, title, action, canEdit, type);
            list.add(dance);
            cursor.moveToNext();
        }
        cursor.close();
        db.close();
        return list;
    }

    public boolean insert(CommandModel dance){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", dance.getTitle());
        values.put("action", String.valueOf(dance.getAction()));
        values.put("can_edit", 1);
        values.put("type", dance.getType());
        long rows = db.insert(DBHelper.TABLE_NAME_COMMAND, null, values);
        db.close();
        return rows != -1;
    }

    public boolean update(CommandModel dance){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        LogUtil.d("update", "id = " + dance.getId());
        LogUtil.d("update", "can = " + dance.isCanEdit());
        values.put("title", dance.getTitle());
        values.put("action", String.valueOf(dance.getAction()));
        long rows = db.update(DBHelper.TABLE_NAME_COMMAND, values, "id=?", new String[]{String.valueOf(dance.getId())});
        db.close();
        return rows == 1;
    }

    public boolean delete(int id){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long rows = db.delete(DBHelper.TABLE_NAME_COMMAND, "id=?", new String[]{String.valueOf(id)});
        return rows == 1;
    }
}
